# Pharos

A private, offline book reader for your phone. It opens EPUB, plain text (with Project Gutenberg cleanup), HTML, Markdown, Word (.docx) and PDF. It has four book styles: Medieval Manuscript, Papyrus Scroll, Sheepskin Tome and Modern Hardcover.

Your books, reading positions, bookmarks, highlights and notes are stored only on your phone. Nothing is uploaded anywhere.

## Put it online with GitHub Pages (one time, about 10 minutes)

1. Sign in at github.com and click **New repository**.
   - Name: `pharos`
   - Visibility: **Public** (free Pages hosting needs a public repository; only the app's code is public, never your books)
   - Click **Create repository**.
2. On the new repository page, click **uploading an existing file**.
3. Unzip `pharos.zip` on a computer. Drag **the contents** of the `pharos` folder into the upload area: `index.html`, `sw.js`, `manifest.webmanifest`, `.nojekyll`, and the `css`, `js`, `fonts`, `icons` and `vendor` folders. Do not drag the folder itself. Then click **Commit changes**.
   - Tip: dragging folders works in Chrome and Edge. If a folder won't upload, use GitHub Desktop, or `git push` from a terminal.
4. Go to **Settings → Pages**. Under *Build and deployment*, set **Source: Deploy from a branch**, **Branch: main**, folder **/ (root)**, then **Save**.
5. Wait a minute. Your app will be at `https://YOUR-USERNAME.github.io/pharos/`.

## Install on your Android phone

1. Open that address in **Chrome** while online.
2. Leave the page open for about 10 seconds. This lets it save itself and its period fonts for offline use.
3. Open Chrome's **⋮ menu** and tap **Add to Home screen**, then **Install**.
4. Launch Pharos from the lighthouse icon. It opens full screen and works with no connection.

## Adding books

- Tap the gold **+** in the library and pick files, or
- In the Downloads app or in Chrome's downloads list, **Share** a book to **Pharos**. This works after the app is installed.
- On Project Gutenberg, choose **EPUB3 (E-readers incl. Send-to-Kindle)** when you can. Plain text works too. Pharos strips the license header and footer, rejoins wrapped lines and finds the chapters.

## Reading

| Gesture | Action |
|---|---|
| Tap the right or left edge (bottom or top edge in Upward mode) | Next or previous page |
| Drag the page | Turn the leaf by hand; let go past about a third of the way to complete the turn |
| Tap the middle | Show or hide the controls |
| Press and hold on text | Highlight in four colors, add a note, or copy |
| Tap a highlight | Change its color, edit its note, or remove it |
| Ribbon icon (top right) | Bookmark this page |
| Contents | Chapters, bookmarks, notes and full-text search |
| Style (Aa) | Book style, Day/Candle/Night, size, spacing, margins, justification, Pages or Scroll, Sideways or Upward page turns |

Each book remembers its own style, so you can read one as a manuscript and another as a hardcover. The papyrus style always unrolls sideways; its rolled ends shrink and grow as you read.

## Updating the app later

Upload the changed files to the repository. In `sw.js`, change `pharos-v1` to `pharos-v2` (and so on) each time. Your phone picks up the new version on the next launch while online; sometimes it takes two launches. Your library is not touched by updates.

## Notes

- Your library lives in the browser storage for this web address. Don't clear Chrome's site data for `github.io`, and keep using the same address.
- DRM-protected books (Kindle, Adobe) cannot be opened. Legacy `.doc` files should be saved as `.docx` first.
- PDFs are shown as fixed pages with a page slider and bookmarks. Book styles, highlights and search apply to reflowable formats only.

## Credits

- PDF rendering: [pdf.js](https://mozilla.github.io/pdf.js/) (Apache 2.0), bundled in `vendor/`.
- Fonts: EB Garamond, IM Fell English, IM Fell DW Pica, UnifrakturMaguntia, Cinzel and Cormorant Garamond from Google Fonts (SIL Open Font License). They are downloaded and cached on first launch. Lora (SIL OFL) is bundled as the offline fallback.
